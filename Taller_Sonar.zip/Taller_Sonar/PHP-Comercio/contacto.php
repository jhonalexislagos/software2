<?php
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		require "fn/email.php";
		require_once "fn/constantes.php";

		enviar(EMAIL_CONTACTO, $_POST["nombre"], "Comentario", $_POST["mensaje"]." email: ".$_POST["email"], false);

		header("Location: index.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="main"> 
					<div class="reservation_top">
						<div class=" contact_right">
							<h3>Contacto</h3>
							<div class="contact-form">
								<form action="#" method="post">
									<input type="text" class="textbox" placeholder="Nombre" name="nombre">
									<input type="text" class="textbox" placeholder="E-Mail" name="email">
									<textarea placeholder="Mensaje" name="mensaje"></textarea>
									<input type="submit" value="Enviar">
									<div class="clearfix"></div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div class="clearfix"></div>
		</div>
		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>