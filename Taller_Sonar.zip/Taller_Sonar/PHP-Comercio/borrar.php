<?php 
	
	require "fn/productos.php";

	$resultado = \productos\borrar($_GET["id"]);

	if ($resultado) {
		header("Location: listado_productos.php");
	}
	else{
		header("Location: listado_productos.php?error=0X003");
	}

 ?>