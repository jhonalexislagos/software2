<?php

	//Controlador frontal

	header("Location: catalogo.php"); // redirecciono a la página por defecto
	exit;

