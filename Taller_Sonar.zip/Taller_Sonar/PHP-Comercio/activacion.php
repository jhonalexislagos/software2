<?php
	
	require "fn/usuarios.php";
	
	$token = ($_GET["code"])? $_GET["code"] : false;

	if($token){
		$activado = \usuarios\activar($token);
	}
	else{
		header("Location: index.php"); exit; // si no vino codigo
	}

	if($activado){
		$mensaje = "Su cuenta se ha activado satisfactoriamente!";
	}
	else{
		$mensaje = "Su cuenta NO se pudo activar";
	}
	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Activación</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
</head>
<body>
	<!--header-->
	<?php include "encabezado.php"; ?>
	<!---->

	<p>
		<?=$mensaje;?>		
	</p>
	<a href="ingreso.php">Ingresar</a>

	<!--footer-->
	<?php include "pie-de-pagina.php"; ?>
	<!---->
</body>
</html>	