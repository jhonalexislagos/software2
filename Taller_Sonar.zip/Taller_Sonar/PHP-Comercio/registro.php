<?php
	$errores = "";
	$nombre = "";
	$apellido = "";
	$email = "";
	$suscribirse = false;

	if(isset($_POST["nombre"])){//existe $_POST["nombre"] ?

		require "fn/validaciones.php";
		require "fn/archivos.php";
		require "fn/seguridad.php";

		// procesando el envio de datos del form

		\archivos\generaLogs("Llenar las variables con lo que vino en POST".json_encode($_POST));
		$nombre = $_POST["nombre"];
		$apellido = $_POST["apellido"];
		$email = $_POST["email"];
		$clave = $_POST["pass"];
		$clave2 = $_POST["pass2"];
		$suscribirse = (isset($_POST["suscribirse"]))? true : false;
		
		if(!\validaciones\validarNombre($nombre)){
			$errores = true;
		}
		
		if(!\validaciones\validarNombre($apellido)){
			$errores = true;
		}
		
		if(!validaciones\validarEmail($email)){
			$errores = true;
		} 
    	
		if(!validaciones\validarClave($clave)){
			$errores = true;
		}

    	if($clave != $clave2){
    		$errores = true;
    	}
    	
		if($errores == ""){
			require 'fn/usuarios.php';
			require 'fn/email.php';
			require_once 'fn/constantes.php';

			$token = sha1(SALT.$email);

			$resultado = \usuarios\registrar($nombre, $apellido, $email, $clave, $suscribirse, $token);

			if($resultado){
				$link = DOMINIO.PAGINA_ACTIVACION."?code=".$token;

				$mensaje = "<p>Ingrese al siguiente link para activar su cuenta:</p><a href='$link'>$link</a>";

				$enviado = enviar($email, "$nombre $apellido", "Activar el usuario de ComercioIT", $mensaje);

				if($enviado){
					\archivos\generaLogs("se envio el mail");
					header("Location: confirmacion.php?email={$email}");exit;
				}
			}

			header("Location: index.php");
			exit;
			
		}
		else{
			$ipcapturada = \seguridad\obtenerIP();
			\archivos\generaLogs("hubo errores en validación php. IP: $ipcapturada");
			header("Location: index.php");
			exit;
		}


	}

	$suscribirse = ($suscribirse)? "checked" : "";

?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	<style>
	.con-error{
		border: 2px solid red!important;
	}
	</style>
	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="register">
					<div class="register-top-grid">
						<h3>NUEVO USUARIO</h3>
						<div id="caja-errores"></div>
						<form action="#" method="post" onsubmit="validar(event)">
							<div class="mation">
								<span>Nombre: <label>*</label></span>
								<input type="text" name="nombre" value="<?=$nombre;?>"> 
								<span>Apellido: <label>*</label></span>
								<input type="text" name="apellido" value="<?=$apellido;?>"> 
								<span>E-Mail: <label>*</label></span>
								<input type="text" name="email" value="<?=$email;?>">
								<span>Contraseña: <label>*</label></span>
								<input type="password" name="pass">
								<span>Repetir Contraseña: <label>*</label></span>
								<input type="password" name="pass2">
								<br><input type="checkbox" name="suscribirse" value="si" <?=$suscribirse;?> /><span>Suscribirse a las novedades</span>
								<div class="register-but">
									<input type="submit" value="Registrarme">
								</div>
							</div>
						</form>
					</div>
					<div class="clearfix"></div>
				</div>
			</section>
			<div class="clearfix"></div>
		</div>

		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
		<script src="js/validacion.js"></script>
	</body>
</html>