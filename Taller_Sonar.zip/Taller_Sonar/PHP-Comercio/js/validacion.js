document.querySelectorAll("input").forEach(function(c){
	c.onfocus = function(){ this.classList.remove("con-error"); };
});

function validar(e){
	e.preventDefault();
	var frm = document.querySelector("form");
	var nombre = frm.querySelector("input[name=nombre]");
	var apellido = frm.querySelector("input[name=apellido]");
	var email = frm.querySelector("input[name=email]");
	var clave = frm.querySelector("input[name=pass]");
	var clave2 = frm.querySelector("input[name=pass2]");
	var suscribirse = frm.querySelector("input[name=suscribirse]");

	var errores = "";

	if(!validarNombre(nombre.value)){
		nombre.classList.add("con-error");
		errores += "<li>El nombre no puede estar vacio</li>";				
	}

	if(!validarNombre(apellido.value)){
		apellido.classList.add("con-error");
		errores += "<li>El apellido no puede estar vacio</li>";
	}
	
	if(!validarEmail(email.value)){
		email.classList.add("con-error");
		errores += "<li>El email no tiene buen formato</li>";
	} 
	
	if(!validarClave(clave.value)){
		clave.classList.add("con-error");
		errores += "<li>la clave no puede tener menos de 8 caracteres y debe sólo puede usar letras y números</li>";
	}

	if(clave.value != clave2.value){
		clave.classList.add("con-error");
		clave2.classList.add("con-error");
		errores += "<li>las claves no son iguales</li>";
	}
	
	if(errores == ""){
		console.log("validacion ok");
		frm.submit(); // hago el submit manualmente
	}
	else{
		document.querySelector("#caja-errores").innerHTML =
		            '<div class="alert alert-danger" role="alert">'+
						'<ul>'+errores+'</ul>'+
				    '</div>';
	}

}

function validarNombre(campo){
	return ( campo != "" && campo.length > 4 );
}
function validarEmail(campo){
	return /[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}/g.test(campo);
}
function validarClave(campo){
	return ( campo.length >= 8 && /[0-9a-zA-Z]+/g.test(campo) );
}