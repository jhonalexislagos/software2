<?php
	session_start();

	$mensaje = "";

	if($_SERVER["REQUEST_METHOD"] == "POST"){
		
		require "fn/seguridad.php";
		$usuario = \seguridad\login($_POST["email"], $_POST["pass"]);

		if($usuario){
			
			$_SESSION["id_usuario"] = $usuario["id"];
			$_SESSION["email"]  = $usuario["email"];
			$_SESSION["perfil"] = $usuario["id_perfil"];
			$_SESSION["nombre"] = $usuario["nombre"];
			header("Location: index.php");
		}
		else{
			$mensaje = "<h1>Usuario y/o Clave incorrecta.</h1>";
		}
	}
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="account_grid">

			<?=$mensaje;?>
				
	<div class="login-right">
		<h3>INGRESO DE USUARIO</h3>
		<form action="#" method="post">
		<div>
			<span>E-Mail:</span>
			<input type="text" name="email"> 
		</div>
		<div>
			<span>Contraseña:</span>
			<input type="password" name="pass"> 
		</div>
			<input type="submit" value="Ingresar">
			<br>
			<a class="forgot" href="#">¿Olvidaste tu contraseña?</a>
		</form>
	</div>	
	<div class=" login-left">
		<h3>¿NUEVO USUARIO?</h3>
		<a class="acount-btn" href="registro.php">Crear una cuenta</a>
	</div>
	<div class="clearfix"></div>
</div>
			</section>
			<div class="clearfix"></div>
		</div>

		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>