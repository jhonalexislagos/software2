<?php

if(!isset($_SESSION)){
	session_start();
}

if(isset($_SESSION["id_usuario"]) && $_SESSION["perfil"]==0){
$opciones =<<<OPC
	<li><a href="listado_productos.php">LISTADO</a></li>
	&nbsp;|&nbsp;
	<li><a href="logout.php">SALIR</a></li>
OPC;
}
elseif(isset($_SESSION["id_usuario"]) && $_SESSION["perfil"]==1){
$opciones =<<<OPC
	<li><a href="ofertas.php">OFERTAS</a></li>
	&nbsp;|&nbsp;	
	<li><a href="contacto.php">CONTACTO</a></li>
	&nbsp;|&nbsp;
	<li><a href="logout.php">SALIR</a></li>
OPC;
}
else{
$opciones =<<<OPC
	<li><a href="ingreso.php"><span></span> INGRESAR</a></li>
	&nbsp;|&nbsp;
	<li><a href="registro.php">REGISTRARME</a></li>
	&nbsp;|&nbsp;
	<li><a href="contacto.php">CONTACTO</a></li>
OPC;
}

?>
		<div class="header">
			<div class="bottom-header">
				<div class="container">
					<div class="header-bottom-left">
						<div class="logo"><a href="index.php">Comercio<strong>IT</strong></a></div>
						<!--div class="search">
							<input type="text" name="q">
							<input type="submit" value="BUSCAR">
						</div-->
						<div class="clearfix"></div>
					</div>
					<div class="header-bottom-right">					
						<!--div class="account">
							<a href="ingreso.html"><span></span> TU CUENTA</a>
						</div-->
						<ul class="login">
							<?=$opciones;?>
						</ul>
						<!--div class="cart"><a href="#"><span></span>CART</a></div-->
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>	
				</div>
			</div>
		</div>