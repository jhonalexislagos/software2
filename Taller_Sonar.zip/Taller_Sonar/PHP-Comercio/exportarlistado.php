<?php 

require "fn/productos.php";
require "lib/phpexcel/PHPExcel.php";
require_once "fn/constantes.php";

$registros = \productos\exportar($_GET["orden"], $_GET["sentido"], $_GET["producto"], $_GET["marca"]);

$objPHPExcel = new PHPExcel();
// Establecer propiedades
$objPHPExcel->getProperties()
->setCreator("Jorge")
->setLastModifiedBy("Jorge")
->setTitle("Listado de productos")
->setSubject("Listado de productos")
->setDescription("Listado de productos")
->setKeywords("Excel Office 2013 openxml php")
->setCategory("Listado de productos");
// Estilos
$styleArray = array(
    'font' => array(
        'bold' => true,
        'color' => array('rgb' => 'FFFFFF'),
    ),
    'fill' => array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'color' => array('rgb' => '435E8B')
    )
);

$stylePar = array(
    'fill' => array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'color' => array('rgb' => '90a8ce')
    )
);


$objPHPExcel->setActiveSheetIndex(0) // nos paramos en la hoja 1 (indice 0)
            ->setCellValue('A1', 'Categoria')
            ->setCellValue('B1', 'Nombre')
            ->setCellValue('C1', 'Precio')
            ->setCellValue('D1', 'Marca')
            ->setCellValue('E1', 'Foto');

// Aplico estilos
$objPHPExcel->getActiveSheet() // me paro en la hoja actual
            ->getStyle('A1:E1') // capturo las celdas
            ->applyFromArray($styleArray); // aplicar estilos desde un array


// Agregar Información
$cant = count($registros);
for($i=0;$i<$cant;$i++){
    $ind = $i + 2;
    $objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A'.$ind, $registros[$i]["nombre_categoria"])
    ->setCellValue('B'.$ind, $registros[$i]["nombre"])
    ->setCellValue('C'.$ind, $registros[$i]["precio"])
    ->setCellValue('D'.$ind, $registros[$i]["nombre_marca"])
    ->setCellValue('E'.$ind, DOMINIO.$registros[$i]["foto"]);

    if ($i%2) {
    	$objPHPExcel->getActiveSheet() // me paro en la hoja actual
            ->getStyle('A'.$ind.':E'.$ind) // capturo las celdas
            ->applyFromArray($stylePar); // aplicar estilos desde un array
    }
    
}
// Ajustar las columnas
foreach(range('A','E') as $columnID) {
    $objPHPExcel->getActiveSheet()
                ->getColumnDimension($columnID) // setea que la dimension de la columna sea la del $columnID
                ->setAutoSize(true);
}

// Renombrar Hoja
$objPHPExcel->getActiveSheet() // me paro en la hoja actual
            ->setTitle('Listado'); // setTitle es para ponerle nombre
// Establecer la hoja activa, para que cuando se abra el documento se muestre primero.
$objPHPExcel->setActiveSheetIndex(0);
$fecha = date("YmdHis");
// Se modifican los encabezados del HTTP para indicar que se envia un archivo de Excel.
// son los encabezados de microsoft que indican que va a abrir un archivo excel. 
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$fecha.'_listados.xlsx"'); // para setear el nombre del archivo.
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007'); 
$objWriter->save('php://output');  // esta linea hace que el archivo se dispare fuera del navegador.
exit;