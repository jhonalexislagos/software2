<?php
	session_start();
	if(!isset($_SESSION["id_usuario"]) || $_SESSION["perfil"]!=0){
		header("Location: index.php");
	}

	require "fn/combos.php";
	require "fn/subidas.php";
	require "fn/productos.php";
	require "fn/archivos.php";

	// valores por defecto (nuevo)
	$nombre="";
	$categoria="";
	$precio="";
	$marca="";
	$fotografia="";
	$foto_anterior="";
	
	if($_SERVER["REQUEST_METHOD"]=="POST"){ 

		//var_dump($_POST); 
		//var_dump($_FILES); exit;
		//$_FILES['fotografia']['tmp_name']

		//completar el formulario con el post (procesamiento)
		$id=$_POST['id'];
		$nombre=$_POST['nombre'];
		$categoria=$_POST['categoria'];
		$precio=$_POST['precio'];
		$marca=$_POST['marca'];
		$fotografia=$_FILES['fotografia'];

		if($id==""){ // alta

			$ruta_img = "";

			if(\subidas\comprobarFoto($fotografia)){
				\archivos\crearRuta("fotos");
				$ruta_img = \subidas\subirFoto($fotografia, "fotos");
			}

			$id_creado = \productos\crear($nombre, $categoria, $precio, $marca, $ruta_img);
			if($id_creado){
				header("Location: producto.php?id={$id_creado}");
			}			
		}
		else{ // actualizacion

			$ruta_img = "";
			if(\subidas\comprobarFoto($fotografia)){
				\archivos\crearRuta("fotos");
				$ruta_img = \subidas\subirFoto($fotografia, "fotos");
			}


			$resultado = \productos\editar($id, $nombre, $categoria, $precio, $marca, $ruta_img);
			if($resultado){
				header("Location: producto.php?id={$id}");
			}			
		}

	}
	else{ 

		$id = (isset($_GET["id"]))? $_GET["id"] : "";

		if($id){ // edicion

			//completar el formulario con el registro obtenido por id (edicion)
			$producto_a_editar = \productos\obtenerProducto($id);

			$id = $id;
			$nombre = $producto_a_editar['nombre'];
			$categoria = $producto_a_editar['cod_categoria'];
			$precio = $producto_a_editar['precio'];
			$marca = $producto_a_editar['cod_marca'];
			$foto_anterior = $producto_a_editar['foto'];

		}

	}
	
	//construir los combos
	$combo_categorias = \combos\crearComboCategorias($categoria);
	$combo_marcas = \combos\crearComboMarcas($marca);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Formulario</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	<style>
		form{ width: 400px; margin: 0 auto; font-family: sans-serif; }
		label{ display: block;  }			
		input, select{ width: 100%; height: 32px; }
		img{ width: 100%; }
	</style>
	<script>
		// permite modificar el preview de la imagen seleccionada en el html
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function (e){
					document.querySelector("#previsualizacion").src = e.target.result;				
				};
				reader.readAsDataURL(input.files[0]);
			}
	    }
	</script>
</head>
<body>
	<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
	<form action="" method="POST" enctype="multipart/form-data">
		<p>
			<label>Nombre del producto</label>
			<input type="text" name="nombre" value="<?=$nombre;?>" />
		</p>
		<p>
			<label>Categoria del producto</label>
			<select name="categoria">			
				<?=$combo_categorias;?>
			</select>
		</p>
		
		<p>
			<label>Precio</label>
			<input type="text" name="precio" value="<?=$precio;?>" />
		</p>
		
		<p>
			<label>Marca del producto</label>
			<select name="marca">			
				<?=$combo_marcas;?>
			</select>
		</p>
		
		<p>
			<label>Foto del producto</label>
			<img id="previsualizacion" src="<?=$foto_anterior;?>" /> 
			<input type="file" name="fotografia" onchange="readURL(this);" />
		</p>

		<input type="submit" value="Guardar">

		<input type="hidden" name="id" value="<?=$id;?>" />
	</form>
	<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
</body>
</html>