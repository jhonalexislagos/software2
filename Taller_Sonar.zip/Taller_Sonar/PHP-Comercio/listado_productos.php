<?php	
	session_start();
	if(!isset($_SESSION["id_usuario"]) || $_SESSION["perfil"]!=0){
		header("Location: index.php");
	}

	require "fn/productos.php";

	$marca ="";
	$producto = "";
	$pagina = 1;
	$orden = 3;
	$sentido = "ASC";

	$error = "";

	if (isset($_GET["error"])) {
		
		require "fn/seguridad.php";
		$error = \seguridad\obtenerError($_GET["error"]);
	}

	if(isset($_GET["pagina"])){
	    $pagina = $_GET["pagina"];
	    $orden = $_GET["orden"];
	    $producto = trim($_GET["producto"]);
	    $marca = trim($_GET["marca"]);
		$sentido = $_GET["sentido"];
	}

	$resultado = \productos\listar($orden, $sentido, $pagina, $producto, $marca);
	$registros = $resultado[0];
	$paginador = $resultado[1];

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="test/estilostest.css">
	<link rel="stylesheet" type="text/css" href="lib/fontawesome/css/font-awesome.css">
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	<script>
			window.addEventListener('load', function(){
				var tag = document.querySelector(".mensaje");
				if(tag.innerHTML == ""){
					tag.style.display = 'none';
				}
				tag.addEventListener('click', function(){
					// agrego la clase que lo desvanece
					tag.classList.add('hidden');
					// despues de 600 milisegundo lo quito para que no ocupe lugar
					setTimeout(function(){
						tag.style.display = 'none';
					},600);
				});
			});
            function enviarPagina(param){
                document.querySelector("#pagina").value = param;
                document.querySelector("#formulario").submit();
            }
            function enviarOrden(param){
                document.querySelector("#orden").value = param;
				
				var anterior_valor = document.querySelector("#sentido").value;
				var sentido = (anterior_valor!="DESC")? "DESC" : "ASC"
				// operador ternario: es un if de una linea.
				// si el valor no es DESC, en sentido se guarda "DESC", sino, se guarda "ASC".
				document.querySelector("#sentido").value = sentido;
                document.querySelector("#formulario").submit();
            }
            function borrar(id,nombre){

            	if (confirm("Desea borrar el producto '" + nombre + "'?")) {
            		location.href = "borrar.php?id=" + id;
            	}

            }

        </script>
        <style type="text/css">
        	.central{
        		text-align: center;
        		padding: 10px;
        	}
        	.central a{
        		background: #42aaf4;
        		color: white;
        		text-decoration: none;
        		border-radius: 6px;
        		padding: 8px;
        	}
        </style>
</head>
<body>
<!--header-->
<?php include "encabezado.php"; ?>
<!---->
	<div class="mensaje"><?=$error;?></div>

	<form id="formulario" action="" method="GET" class="central" >
		<input type="text" name="producto" placeholder="Filtrar Producto" value="<?=$producto;?>" />
		<input type="text" name="marca" placeholder="Filtrar Marca" value="<?=$marca;?>" />
		
		<input type="hidden" id="pagina" name="pagina" value="<?=$pagina;?>" />
		<input type="hidden" id="orden" name="orden" value="<?=$orden;?>" />
		<input type="hidden" id="sentido" name="sentido" value="<?=$sentido;?>" />		
		<input type="submit" value="filtrar" />
		
	</form>

	<table>
		<thead>
			<tr>
				<th><a href="javascript:void(0);" onclick="enviarOrden(1)">Categoria</a></th>
				<th><a href="javascript:void(0);" onclick="enviarOrden(2)">Producto</a></th>
				<th><a href="javascript:void(0);" onclick="enviarOrden(3)">Precio</a></th>
				<th><a href="javascript:void(0);" onclick="enviarOrden(4)">Marca</a></th>
				<th>Imagen</th>
				<th>Acciones</th>
			</tr>
		</thead>
		<tbody>
			<?=$registros;?>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="6">
					<?=$paginador;?>
				</td>
			</tr>
		</tfoot>	
	</table>

	<div class="central" >
		<a href="formulario.php">Nuevo producto</a>
		<a href="exportarlistado.php?orden=<?=$orden;?>&sentido=<?=$sentido;?>&producto=<?=$producto;?>&marca=<?=$marca;?>">Exportar a excel</a>
	</div>
<!--footer-->
<?php include "pie-de-pagina.php"; ?>
<!---->
</body>
</html>