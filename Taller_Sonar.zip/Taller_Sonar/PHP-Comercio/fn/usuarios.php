<?php

	namespace usuarios{
		use \PDO;
		require_once "constantes.php";

		function registrar($nombre, $apellido, $email, $clave, $suscribirse, $token){
			$clave = md5(SALT.$clave);//encriptar

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$query = "INSERT INTO usuarios
			          (nombre, email, clave, token, activo, id_perfil) 
			          VALUES 
			          (:nombre, :email, :clave, :token, 0, 1)
			         ";
			$statement = $cnx->prepare($query);
			$statement->bindParam(":nombre", $nombre, PDO::PARAM_STR);
			$statement->bindParam(":email", $email, PDO::PARAM_STR);
			$statement->bindParam(":clave", $clave, PDO::PARAM_STR);
			$statement->bindParam(":token", $token, PDO::PARAM_STR);
			//$statement->bindParam(":activo", 0, PDO::PARAM_INT);
			//$statement->bindParam(":perfil", 1, PDO::PARAM_INT);
			return $statement->execute();
		}

		function activar($token){
			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$query = "SELECT id FROM usuarios WHERE token = :token ";
			$statement = $cnx->prepare($query);
			$statement->bindParam(":token", $token, PDO::PARAM_STR);
			if($statement->execute()){
				$fila = $statement->fetch(PDO::FETCH_ASSOC);
			}
			if(isset($fila["id"])){
				$query2 = "UPDATE usuarios SET activo = 1 WHERE id = :usuario";
				$statement2 = $cnx->prepare($query2);
				$statement2->bindParam(":usuario", $fila["id"], PDO::PARAM_INT);
				return $statement2->execute();
			}
			else{
				return false;
			}
		}

	}
