<?php

	namespace seguridad{
		require_once "constantes.php";
		use \PDO;

		function login($email, $clave){
			$clave = md5(SALT.$clave);

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$query = "SELECT id, nombre, email, id_perfil
					  FROM usuarios
					  WHERE activo = 1
					  AND email = :email
					  AND clave = :clave
			         ";
			$stm = $cnx->prepare($query);
			$stm->bindParam(":email", $email, PDO::PARAM_STR);
			$stm->bindParam(":clave", $clave, PDO::PARAM_STR);
			if($stm->execute()){
				$fila = $stm->fetch(PDO::FETCH_ASSOC);
				return $fila;
			}
			else{
				return false;
			}
		}

		function obtenerError($codigo){

			$text="Desconocido";
			
			switch ($codigo) {
				case '0X003':
					$text = "No se pudo borrar el producto";
					break;
				
				default:
					# code...
					break;
			}

			return $text;
		}

		function obtenerIP() {
			if(isset($_SERVER["HTTP_CLIENT_IP"])){
	            return $_SERVER["HTTP_CLIENT_IP"];
	        }
	        elseif(isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
	            return $_SERVER["HTTP_X_FORWARDED_FOR"];
	        }
	        elseif(isset($_SERVER["HTTP_X_FORWARDED"])){
	            return $_SERVER["HTTP_X_FORWARDED"];
	        }
	        elseif(isset($_SERVER["HTTP_FORWARDED_FOR"])){
	            return $_SERVER["HTTP_FORWARDED_FOR"];
	        }
	        elseif(isset($_SERVER["HTTP_FORWARDED"])){
	            return $_SERVER["HTTP_FORWARDED"];
	        }	        
	        elseif(isset($_SERVER["REMOTE_ADDR"])){
	            return $_SERVER["REMOTE_ADDR"];
	        }
	        else{
	        	return "Desconocido";
	        }
		}

	}