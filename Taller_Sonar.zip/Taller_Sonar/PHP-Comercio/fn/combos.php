<?php

	namespace combos{

		use \PDO;
		require_once "constantes.php";

		function crearComboCategorias($categoria){
			$options = '<option value="0">Elegir una categoria</option>';
			$query = "SELECT cod_categoria id, nombre_categoria nombre FROM categorias";
			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$result = $cnx->query($query);
			while($fila = $result->fetch(PDO::FETCH_ASSOC)){

				$seleccionado = ($categoria==$fila["id"]) ? "selected" : "";
					$options.= "<option value='{$fila["id"]}' {$seleccionado}>{$fila["nombre"]}</option>";				
			}


			return $options;
		}

		function crearComboMarcas($marca){
			$options = '<option value="0">Elegir una marca</option>';
			$query = "SELECT cod_marca id, nombre_marca nombre FROM marcas";
			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$result = $cnx->query($query);
			while($fila = $result->fetch(PDO::FETCH_ASSOC)){

				if ($marca==$fila["id"]) {
					$options.= "<option value='{$fila["id"]}' selected>{$fila["nombre"]}</option>";
				}
				else{
					$options.= "<option value='{$fila["id"]}'>{$fila["nombre"]}</option>";
				}

			}
			return $options;
		}

	}