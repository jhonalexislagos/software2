<?php

	namespace productos{

		use \PDO;
		require_once "constantes.php";


		function listarCatalogo($orden, $sentido, $pagina){
			$cantidad_mostrada = 10;
			$filas = "";

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$query = "SELECT C.nombre_categoria,
			                 P.nombre,
			                 P.precio,
			                 M.nombre_marca,
			                 P.foto,
			                 P.id_producto
					  FROM productos P 
					  LEFT JOIN categorias C ON(C.cod_categoria=P.cod_categoria)
					  LEFT JOIN marcas M ON(M.cod_marca=P.cod_marca)
					  WHERE 1=1			 
					  ORDER BY $orden $sentido					  
					 ";
			$objproducto = $cnx->prepare($query);
			
			if ( $objproducto->execute() ) {

				 $cantidad_registros = $objproducto->rowCount();

				 $cantidad_paginas = ceil($cantidad_registros / $cantidad_mostrada);

				 $paginador = "";
				for($i=1 ; $i <= $cantidad_paginas ; $i++){
					$paginador .= "<a onclick='enviarPagina({$i})' href='#'>{$i}</a> ";
				}

				 $registros_a_saltar = ($pagina - 1) * $cantidad_mostrada;


				 $objproducto = $cnx->prepare($query."LIMIT $cantidad_mostrada OFFSET $registros_a_saltar");
			
				if ( $objproducto->execute() ) {

					$producto_nro = 1;
					while($producto = $objproducto->fetch(PDO::FETCH_ASSOC)){

						$producto['foto'] = ($producto['foto']!="")? $producto['foto'] : "images/productos/P001.jpg";
						$ultimo_fila = ($producto_nro%3==0)? "grid-top-chain" : "";

						//HEREDOC:
						$filas .=<<<FILA
						<!-- Producto #{$producto_nro} -->
						<div class="col-sm-4 col-md-4 chain-grid {$ultimo_fila}" style="margin-bottom: 10px;">
							<a href="producto.php?id={$producto['id_producto']}">
								<img class="img-responsive chain" src="{$producto['foto']}" alt="{$producto['nombre']}" style="width:300px;height:300px" />
							</a>
							<div class="grid-chain-bottom">
								<h6 class="truncate"><a href="producto.php?id={$producto['id_producto']}">{$producto['nombre']}</a></h6>
								<div class="star-price">
									<div class="dolor-grid"> 
										<span class="actual">$ {$producto['precio']}</span>
									</div>
									<a class="now-get get-cart" href="producto.php?id={$producto['id_producto']}">VER MÁS</a> 
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
FILA;
						$producto_nro++;
					}
				}

			}
			return array($filas, $paginador);

		}				

		function listar($orden, $sentido, $pagina, $f_nombre, $f_marca){
			$cantidad_mostrada = 10;
			$filas = "";

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$filtro_nombre = ($f_nombre!="")? " AND P.nombre LIKE '%$f_nombre%' " : "";
			$filtro_marca = ($f_marca!="")? " AND M.nombre_marca LIKE '%$f_marca%' " : "";

			$query = "SELECT C.nombre_categoria,
			                 P.nombre,
			                 P.precio,
			                 M.nombre_marca,
			                 P.foto,
			                 P.id_producto
					  FROM productos P 
					  LEFT JOIN categorias C ON(C.cod_categoria=P.cod_categoria)
					  LEFT JOIN marcas M ON(M.cod_marca=P.cod_marca)
					  WHERE 1=1
					  $filtro_nombre
					  $filtro_marca					 
					  ORDER BY $orden $sentido					  
					 ";
			$objproducto = $cnx->prepare($query);
			
			if ( $objproducto->execute() ) {

				 $cantidad_registros = $objproducto->rowCount();

				 $cantidad_paginas = ceil($cantidad_registros / $cantidad_mostrada);

				 $paginador = "";
				for($i=1 ; $i <= $cantidad_paginas ; $i++){
					$paginador .= "<a onclick='enviarPagina({$i})' href='#'>{$i}</a> ";
				}

				 $registros_a_saltar = ($pagina - 1) * $cantidad_mostrada;


				 $objproducto = $cnx->prepare($query."LIMIT $cantidad_mostrada OFFSET $registros_a_saltar");
			
				if ( $objproducto->execute() ) {

					while($producto = $objproducto->fetch(PDO::FETCH_ASSOC)){

						//HEREDOC:
						$filas .=<<<FILA
						<tr>
									<td>{$producto['nombre_categoria']}</td>
									<td>{$producto['nombre']}</td>
									<td>{$producto['precio']}</td>
									<td>{$producto['nombre_marca']}</td>
									<td><img src='{$producto['foto']}' width='150' /></td>
									<td><a href='formulario.php?id={$producto['id_producto']}'><i class='fa fa-pencil'></i></a>|<a href='javascript:void(0)' onclick="borrar({$producto['id_producto']},'{$producto['nombre']}')"><i class='fa fa-trash'></i></a></td>
							   </tr>
FILA;
					}
				}

			}
			return array($filas, $paginador);

		}

		function exportar($orden, $sentido, $f_nombre, $f_marca){
			
			$filas = "";

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$filtro_nombre = ($f_nombre!="")? " AND P.nombre LIKE '%$f_nombre%' " : "";
			$filtro_marca = ($f_marca!="")? " AND M.nombre_marca LIKE '%$f_marca%' " : "";

			$query = "SELECT C.nombre_categoria,
			                 P.nombre,
			                 P.precio,
			                 M.nombre_marca,
			                 P.foto,
			                 P.id_producto
					  FROM productos P 
					  LEFT JOIN categorias C ON(C.cod_categoria=P.cod_categoria)
					  LEFT JOIN marcas M ON(M.cod_marca=P.cod_marca)
					  WHERE 1=1
					  $filtro_nombre
					  $filtro_marca					 
					  ORDER BY $orden $sentido					  
					 ";
			$objproducto = $cnx->prepare($query);
			
			if ( $objproducto->execute() ) {

				$productos = $objproducto->fetchAll(PDO::FETCH_ASSOC);

			}
			else{
				$productos = array();
			}

			return $productos;

		}

		function crear($nombre, $categoria, $precio, $marca, $foto){

			//$foto = "ZZZZZZ";
			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);
			$query = "INSERT INTO productos(nombre, 
			                                precio, 
			                                cod_marca, 
			                                cod_categoria,
			                                foto)
			               VALUES (
			                       :nombre, 
			                       :precio, 
			                       :marca, 
			                       :categoria, 
			                       :foto)";
			$producto = $cnx->prepare($query);
			$producto->bindParam(":nombre", $nombre, PDO::PARAM_STR);
			$producto->bindParam(":precio", $precio, PDO::PARAM_INT);
			$producto->bindParam(":marca", $marca, PDO::PARAM_INT);
			$producto->bindParam(":categoria", $categoria, PDO::PARAM_INT);
			$producto->bindParam(":foto", $foto, PDO::PARAM_STR);
			if( $producto->execute() ){
				$result = $cnx->query("SELECT id_producto FROM productos ORDER BY 1 DESC LIMIT 1");
				$fila = $result->fetch(PDO::FETCH_ASSOC);
				return $fila["id_producto"];
			}
			return false;
		}

		function editar($id, $nombre, $categoria, $precio, $marca, $nueva_foto){

			$modificar_foto = ($nueva_foto) ? "foto = :foto, " : "";

			if ($nueva_foto) {
				$producto_original = obtenerProducto($id);
				unlink($producto_original['foto']); //borra archivo que pasamos por ruta
			}
			
			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$query = "UPDATE productos
					  SET {$modificar_foto}
					  nombre = :nombre,
					  cod_categoria = :cod_categoria,
					  precio = :precio,
					  cod_marca = :cod_marca
					  WHERE id_producto = :id";

			$objProducto = $cnx->prepare($query);

			$objProducto->bindParam(":nombre", $nombre, PDO::PARAM_STR);
			$objProducto->bindParam(":cod_categoria", $categoria, PDO::PARAM_INT);
			$objProducto->bindParam(":precio", $precio, PDO::PARAM_INT);
			$objProducto->bindParam(":cod_marca", $marca, PDO::PARAM_INT);
			$objProducto->bindParam(":id", $id, PDO::PARAM_INT);
			if ($nueva_foto) {
				$objProducto->bindParam(":foto", $nueva_foto, PDO::PARAM_STR);
			}
			
			return $objProducto->execute();

		}

		function borrar($id){

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$query = "DELETE FROM productos WHERE id_producto = :id";

			$objProducto = $cnx->prepare($query);

			$objProducto->bindParam(":id", $id, PDO::PARAM_INT);
			return $objProducto->execute();
			
		}

		function obtenerProducto($id){

			$cnx = new PDO("mysql:host=".HOST.";dbname=".NAME, USER, PASS);

			$query = "SELECT * FROM productos WHERE id_producto = :id";

			$objProducto = $cnx->prepare($query);

			$objProducto->bindParam(":id", $id, PDO::PARAM_INT);
			$objProducto->execute();
				
			$fila = $objProducto->fetch(PDO::FETCH_ASSOC);
			return $fila;			
		}

	}