<?php

// Defino en una constante el nombre del archivo.
define("ARCHIVO_VISITAS", "visitas.txt");

function contarVisitante(){
	if (file_exists(ARCHIVO_VISITAS)) { // Si el archivo existe...
	    $fp = fopen(ARCHIVO_VISITAS, "r"); // Abro en modo lectura.
	    $cant = fread($fp, filesize(ARCHIVO_VISITAS)); // Leo todo el archivo de texto.
	    fclose($fp); // Cierro el archivo de texto.
	} else { // Si el archivo no existe...
	    $cant = 0; // Seteo la cantidad de visitas en 0
	}

	$cant++; // Aumento en 1 la cantidad de visitas.
	$fp = fopen (ARCHIVO_VISITAS, "w" ); // Abro el archivo en modo lectura.
	fwrite($fp , $cant); // Escribo la cantidad de visitas en el archivo.
	fclose($fp); // Cierro el archivo.

	return $cant; // Imprimo la cantidad de visitas.
}
	