<?php
	namespace archivos{

		function generaLogs($accion){
		    //Definimos la hora de la accion
		    $hora = str_pad(date("H:i:s"), 10, " "); //  hh:mm:ss
		    $accion = str_pad($accion, 50, " ");
		    $cadena = $hora.$accion;

		    //Creamos dinamicamente el nombre del archivo por dia
		    $pre = "CONSOLE-log-";
		    $date = date("ymd"); //aammddhhmmss
		    $fileName = $pre.$date;

		    //Creamos el directorio de logs
		    $ruta = "logs";
		    crearRuta($ruta);

		    $f = fopen("$ruta/$fileName.txt", "a");
		         fputs($f, $cadena."\r\n") or die("no se pudo crear o editar el archivo");
		    fclose($f);   
		}
		function crearCarpeta($carpeta){             
		    if (!is_dir($carpeta)) { // si la carpeta no existe
		        mkdir($carpeta, 0775); //la creo dando todos los permisos necesarios para guardar imagenes en ella
		        chmod($carpeta, 0775);
		    }
		}
		function crearRuta($ruta){
		    $dirs = explode("/", $ruta);
		    $acumulado = "";

		    for($i=0; $i < count($dirs); $i++){
		        crearCarpeta($acumulado.$dirs[$i]);
		        $acumulado .= $dirs[$i] . "/";
		    }
		}

	}