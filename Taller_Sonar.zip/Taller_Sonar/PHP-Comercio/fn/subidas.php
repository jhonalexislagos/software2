<?php

	namespace subidas{

		function subirFoto($file, $ruta){
			$ruta = $ruta."/".date("Ymdhis")."_".$file['name'];
			move_uploaded_file($file['tmp_name'], $ruta);
			return $ruta;
		}
		function comprobarFoto($file){
			return ($file['size']>0 && $file['error']==0);
		}

	}