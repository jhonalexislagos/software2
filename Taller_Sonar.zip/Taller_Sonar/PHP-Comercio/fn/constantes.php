<?php

define("HOST", "localhost");
define("USER", "root");
define("PASS", "");
define("NAME", "limon");

define("DOMINIO", "localhost/roberto/comercio/");
define("PAGINA_ACTIVACION", "activacion.php");
define("SALT", "claveFuerte");

define("SERVIDOR_EMAIL", "smtp.gmail.com");
define("PUERTO_EMAIL", 587);
define("USUARIO_EMAIL", "tu_email_para_desarrollo@gmail.com");
define("CLAVE_EMAIL", "tu_clave");
define("NIVEL_ERROR", 2); // poner en cero en producción
define("FROM_EMAIL", "administrador@misitio.com");
define("NAME_EMAIL", "Administrador");

define("EMAIL_CONTACTO", "mail_contacto_visitantes@gmail.com");

