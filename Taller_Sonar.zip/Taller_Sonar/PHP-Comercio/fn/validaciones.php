<?php
	namespace validaciones{
	
		function validarNombre($campo){
			return ( $campo != "" && strlen($campo) > 4 );
		}

		function validarEmail($campo){
			return preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $campo);
		}

		function validarClave($campo){
			return ( strlen($campo) >= 8 && preg_match("/^[0-9a-zA-Z]+$/", $campo) ); // Solo letras en mayusculas/minusculas y numeros. No se admite cadena vacia
		}

	}