<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<title>ComercioIT | Tu E-Shop en PHP</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<!--theme-style-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--fonts-->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
	<!--//fonts-->
	<script src="js/jquery.min.js"></script>
	<!--script-->
	</head>
	<body> 
		<!--header-->
		<?php include "encabezado.php"; ?>
		<!---->
		<div class="container">
			<section id="page">
				<div class="cat-product">
					<div class="w_content">
						<div class="women">
							<a href="#">
								<h4>Categoria #1 - <span>4449 items</span></h4>
							</a>
							<ul class="w_nav">
								<li>Ordernar por: </li>
								<li><a class="active" href="#">Más recientes</a></li> |
								<li><a href="#">Menor precio</li> |
								<li><a href="#">Mayor precio</a></li> 
								<div class="clearfix"></div>	
							</ul>
							<div class="clearfix"></div>	
						</div>
					</div>
					<!-- grids_of_4 -->
					<div class="grid-product">
						<!-- Producto #1 -->
						<div class="product-grid">
							<div class="content_box">
								<a href="producto.php">
									<div class="left-grid-view grid-view-left">
										<img src="images/productos/P001.jpg" class="img-responsive watch-right" alt=""/>
									</div>
								</a>
								<h4><a href="#">Duis autem</a></h4>
								<p>It is a long established fact that a reader</p>
								<span>$499</span>
							</div>
						</div>
						<!-- Producto #2 -->
						<div class="product-grid">
							<div class="content_box">
								<a href="producto.php">
									<div class="left-grid-view grid-view-left">
										<img src="images/productos/P002.jpg" class="img-responsive watch-right" alt=""/>
									</div>
								</a>
								<h4><a href="#">Duis autem</a></h4>
								<p>It is a long established fact that a reader</p>
								<span>$499</span>
							</div>
						</div>
						<!-- Producto #3 -->
						<div class="product-grid">
							<div class="content_box">
								<a href="producto.php">
									<div class="left-grid-view grid-view-left">
										<img src="images/productos/P003.jpg" class="img-responsive watch-right" alt=""/>
									</div>
								</a>
								<h4><a href="#">Duis autem</a></h4>
								<p>It is a long established fact that a reader</p>
								<span>$499</span>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</section>
			<div class="clearfix"></div>
		</div>

		<!---->
		<?php include "pie-de-pagina.php"; ?>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>